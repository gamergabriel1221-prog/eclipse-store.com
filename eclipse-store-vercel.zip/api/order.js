// O cliente consulta o próprio pedido com id + token (guardado só no navegador dele).
const { r, safeEq } = require('./_lib');
module.exports = async (req, res) => {
  try {
    const { id, token } = req.query || {};
    const raw = /^[a-f0-9]{12}$/.test(id || '') ? await r('GET', 'order:' + id) : null;
    res.setHeader('Cache-Control', 'no-store');
    if (!raw) return res.status(404).json({ error: 'Pedido não encontrado' });
    const o = JSON.parse(raw);
    if (!safeEq(token, o.token)) return res.status(403).json({ error: 'Acesso negado' });
    const done = o.status === 'delivered' || o.status === 'paid_missing';
    res.json({ id: o.id, status: o.status, names: o.names, total: o.total, delivered: done ? o.delivered : undefined });
  } catch (e) { res.status(500).json({ error: 'Erro no servidor' }); }
};
