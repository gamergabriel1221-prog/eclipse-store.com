const crypto = require('crypto');
const URL_ = process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL;
const TOK = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN;
const H = () => ({ Authorization: 'Bearer ' + TOK, 'Content-Type': 'application/json' });
async function r(...cmd) {
  const x = await fetch(URL_, { method: 'POST', headers: H(), body: JSON.stringify(cmd) });
  const d = await x.json();
  if (d.error) throw new Error(d.error);
  return d.result;
}
async function pipe(cmds) {
  const x = await fetch(URL_ + '/pipeline', { method: 'POST', headers: H(), body: JSON.stringify(cmds) });
  const d = await x.json();
  return d.map(i => { if (i.error) throw new Error(i.error); return i.result; });
}
const safeEq = (a, b) => {
  a = Buffer.from(String(a || '')); b = Buffer.from(String(b || ''));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
};
const host = req => 'https://' + (req.headers['x-forwarded-host'] || req.headers.host);
const rid = n => crypto.randomBytes(n).toString('hex');
const isAdmin = req => !!process.env.ADMIN_KEY && safeEq(req.headers['x-admin-key'], process.env.ADMIN_KEY);
module.exports = { r, pipe, safeEq, host, rid, isAdmin };
