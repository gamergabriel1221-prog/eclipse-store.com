// O Mercado Pago avisa aqui. Confirmamos o pagamento direto na API deles (não confiamos no aviso) e entregamos a conta.
const { r, pipe } = require('./_lib');
module.exports = async (req, res) => {
  let lockKey = null;
  try {
    const q = req.query || {}, b = req.body || {};
    const type = q.type || q.topic || b.type || b.topic || '';
    const pid = q['data.id'] || (b.data && b.data.id) || q.id;
    if (!pid || !/payment/.test(type)) return res.status(200).end('ok');
    const pr = await fetch('https://api.mercadopago.com/v1/payments/' + encodeURIComponent(pid), {
      headers: { Authorization: 'Bearer ' + process.env.MP_ACCESS_TOKEN }
    });
    const p = await pr.json();
    if (p.status !== 'approved' || !p.external_reference) return res.status(200).end('ok');
    const raw = await r('GET', 'order:' + p.external_reference);
    if (!raw) return res.status(200).end('ok');
    const o = JSON.parse(raw);
    if (o.status !== 'pending' || Number(p.transaction_amount) < o.total - 0.01) return res.status(200).end('ok');
    lockKey = 'lock:' + o.id;
    if (!(await r('SET', lockKey, '1', 'NX', 'EX', '300'))) return res.status(200).end('ok');
    const delivered = [];
    let missing = 0;
    for (let i = 0; i < o.ids.length; i++) {
      const accId = await r('RPOP', 'stock:' + o.ids[i]); // retira do estoque: cada conta só é entregue uma vez
      const acc = accId && (await r('GET', 'acc:' + accId));
      if (!acc) { missing++; continue; }
      const a = JSON.parse(acc);
      delivered.push({ produto: o.names[i], login: a.login, senha: a.senha, extra: a.extra || '' });
    }
    o.status = missing ? 'paid_missing' : 'delivered';
    o.delivered = delivered;
    o.paidAt = Date.now();
    o.payment = String(pid);
    await r('SET', 'order:' + o.id, JSON.stringify(o));
    res.status(200).end('ok');
  } catch (e) {
    if (lockKey) { try { await r('DEL', lockKey); } catch (_) {} }
    res.status(500).end('erro'); // o Mercado Pago tenta de novo
  }
};
