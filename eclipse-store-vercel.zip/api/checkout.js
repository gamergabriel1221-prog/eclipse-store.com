// Cria o pedido e o pagamento no Mercado Pago. Preço e produto vêm do produtos.json publicado (nunca do navegador).
const { r, pipe, host, rid } = require('./_lib');
module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método inválido' });
  try {
    const { ids, email } = req.body || {};
    if (!Array.isArray(ids) || !ids.length || ids.length > 10 || !/^\S+@\S+\.\S+$/.test(email || ''))
      return res.status(400).json({ error: 'Dados inválidos' });
    const base = host(req);
    const cr = await fetch(base + '/produtos.json', { cache: 'no-store' });
    if (!cr.ok) return res.status(500).json({ error: 'Catálogo (produtos.json) não publicado' });
    const cat = await cr.json();
    const items = ids.map(id => cat.find(p => String(p.id) === String(id)));
    if (items.some(p => !p)) return res.status(400).json({ error: 'Produto não encontrado no catálogo publicado' });
    const need = {};
    ids.forEach(i => (need[i] = (need[i] || 0) + 1));
    for (const id of Object.keys(need)) {
      const n = await r('LLEN', 'stock:' + id);
      if (n < need[id]) return res.status(409).json({ error: 'Sem estoque: ' + items.find(p => String(p.id) === id).name });
    }
    const price = p => Math.round(Number(p.price) * 100) / 100;
    const total = Math.round(items.reduce((s, p) => s + price(p), 0) * 100) / 100;
    const id = rid(6), token = rid(16);
    const order = { id, token, email, ids, names: items.map(p => p.name), total, status: 'pending', created: Date.now() };
    await pipe([['SET', 'order:' + id, JSON.stringify(order)], ['LPUSH', 'orders', id]]);
    const mp = await fetch('https://api.mercadopago.com/checkout/preferences', {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + process.env.MP_ACCESS_TOKEN, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        items: items.map(p => ({ title: p.name, quantity: 1, unit_price: price(p), currency_id: 'BRL' })),
        payer: { email },
        external_reference: id,
        notification_url: base + '/api/webhook',
        back_urls: { success: base + '/?pedido=' + id, pending: base + '/?pedido=' + id, failure: base + '/?pedido=' + id },
        auto_return: 'approved'
      })
    });
    const d = await mp.json();
    if (!d.init_point) return res.status(502).json({ error: 'Mercado Pago recusou criar o pagamento' });
    res.json({ id, token, url: d.init_point });
  } catch (e) { res.status(500).json({ error: 'Erro no servidor' }); }
};
