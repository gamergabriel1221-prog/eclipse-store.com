// Só você (senha ADMIN_KEY): cadastrar/ver/remover contas do estoque e ver pedidos.
const { r, pipe, rid, isAdmin } = require('./_lib');
module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).end();
  if (!isAdmin(req)) return res.status(401).json({ error: 'Senha de administrador incorreta' });
  try {
    const { action, productId, lines, accId } = req.body || {};
    const pid = String(productId || '').replace(/[^0-9a-z_-]/gi, '');
    if (action === 'add') {
      const cmds = [];
      for (const l of String(lines || '').split('\n').map(x => x.trim()).filter(Boolean).slice(0, 200)) {
        const [main, ...ex] = l.split(' | ');
        const i = main.indexOf(':');
        if (i < 1) continue;
        const id = rid(6);
        cmds.push(['SET', 'acc:' + id, JSON.stringify({ login: main.slice(0, i).trim(), senha: main.slice(i + 1).trim(), extra: ex.join(' | ') })], ['LPUSH', 'stock:' + pid, id]);
      }
      if (!cmds.length || !pid) return res.status(400).json({ error: 'Nenhuma linha válida. Use login:senha' });
      const added = cmds.length / 2;
      cmds.push(['SADD', 'stockids', pid]);
      await pipe(cmds);
      return res.json({ ok: true, added });
    }
    if (action === 'list') {
      const ids = await r('LRANGE', 'stock:' + pid, 0, -1);
      const vals = ids.length ? await pipe(ids.map(i => ['GET', 'acc:' + i])) : [];
      return res.json({ items: vals.map((v, k) => ({ id: ids[k], ...JSON.parse(v || '{}') })) });
    }
    if (action === 'remove') {
      const a = String(accId || '').replace(/[^a-f0-9]/g, '');
      await pipe([['LREM', 'stock:' + pid, 0, a], ['DEL', 'acc:' + a]]);
      return res.json({ ok: true });
    }
    if (action === 'orders') {
      const ids = await r('LRANGE', 'orders', 0, 49);
      const raws = ids.length ? await pipe(ids.map(i => ['GET', 'order:' + i])) : [];
      return res.json({ orders: raws.filter(Boolean).map(v => { const o = JSON.parse(v); return { id: o.id, email: o.email, names: o.names, total: o.total, status: o.status, created: o.created }; }) });
    }
    res.status(400).json({ error: 'Ação inválida' });
  } catch (e) { res.status(500).json({ error: 'Erro no servidor' }); }
};
