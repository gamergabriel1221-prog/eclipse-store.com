// Público: devolve só a QUANTIDADE em estoque de cada produto (nunca login/senha).
const { r, pipe } = require('./_lib');
module.exports = async (req, res) => {
  try {
    const ids = await r('SMEMBERS', 'stockids');
    const counts = {};
    if (ids.length) {
      const n = await pipe(ids.map(i => ['LLEN', 'stock:' + i]));
      ids.forEach((i, k) => (counts[i] = n[k]));
    }
    res.setHeader('Cache-Control', 'no-store');
    res.json({ counts });
  } catch (e) { res.status(500).json({ error: 'erro' }); }
};
