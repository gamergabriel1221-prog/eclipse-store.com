# Eclipse Store: entrega automática de contas

## O que tem aqui
- `index.html` — o site
- `api/` — o servidor (funções do Vercel): estoque, pagamento, confirmação e entrega
- `package.json`

Você também precisa do `produtos.json` (exportado pelo Admin do site) na mesma pasta. O servidor lê os preços dele, nunca do navegador do cliente.

## Passo a passo
1. **GitHub:** envie para o repositório o `index.html`, o `package.json` e a pasta `api` (arraste a pasta inteira em Add file → Upload files), junto do `produtos.json`.
2. **Banco de dados (grátis):** no Vercel, abra o projeto → **Storage** → **Create Database** → **Upstash Redis** (plano Free) → conecte ao projeto. Isso cria as variáveis do banco sozinho.
3. **Mercado Pago:** em mercadopago.com.br/developers → Suas integrações → crie uma aplicação (Checkout Pro) → **Credenciais de produção** → copie o **Access Token**.
4. **Variáveis no Vercel** (Settings → Environment Variables):
   - `MP_ACCESS_TOKEN` = o Access Token do passo 3
   - `ADMIN_KEY` = uma senha forte que só você sabe (a senha do estoque)
5. **Redeploy:** Deployments → os três pontinhos do último → Redeploy.
6. **Cadastrar contas:** no site, entre como admin → ⚙ Admin → 📦 Estoque e pedidos (servidor). Digite a `ADMIN_KEY`, escolha o produto e cole uma conta por linha: `login:senha` (opcional: `login:senha | observação`).
7. **Teste:** crie um produto de R$ 1,00, cadastre 1 conta e compre. Depois do pagamento, o login e a senha aparecem na tela e em 📦 Pedidos.

## Regras importantes
- O ID do produto no Admin tem que ser o mesmo do `produtos.json` publicado. Se mudar produtos, exporte e publique o `produtos.json` de novo.
- Nunca coloque login ou senha no `produtos.json` nem na descrição do produto.
- Nunca mande o Access Token ou a `ADMIN_KEY` para ninguém.
- Produto sem estoque cadastrado aparece como **Esgotado**.
- Se duas pessoas pagarem pela última conta ao mesmo tempo, a segunda fica com status "paid_missing": reembolse pelo Mercado Pago.
- Reembolsos são feitos no painel do Mercado Pago, o site não faz.
